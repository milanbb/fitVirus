%doubling time
tend = 25;
t = 0:0.1:tend;
[china,t2c] = doublingTime(t,80793,0.226,420);
[italy,t2i] = doublingTime(t,40781,0.245,172);
[southKorea,t2sk] = doublingTime(t,7944,0.375,83);
[slo,t2slo] = doublingTime(t,445,0.522,3);
figure
hold on
plot(t,china,'LineWidth',2)
plot(t,italy,'LineWidth',2)
plot(t,southKorea,'LineWidth',2)
plot(t,slo,'LineWidth',2)
legend('China','Italy','South Korea','Slovenia','Location','best','FontSize',12)
h=plot([t2c,t2c],[0,10])
h.Annotation.LegendInformation.IconDisplayStyle = 'off';
h=plot([t2i,t2i],[0,10])
h.Annotation.LegendInformation.IconDisplayStyle = 'off';
h=plot([t2sk,t2sk],[0,10])
h.Annotation.LegendInformation.IconDisplayStyle = 'off';
h=plot([t2slo,t2slo],[0,10])
h.Annotation.LegendInformation.IconDisplayStyle = 'off';
xlabel('time (day)')
ylabel('doubling time (day)')
ylim([0 10])
grid on
function [dt,tt] = doublingTime(t,K,r,C0)
    A = K/C0 - 1;
    dt = log(2)/r - t - log(1/A - exp(-r*t))/r;
    tt = log(A)/r;
    dt(t>=tt) = NaN;
end