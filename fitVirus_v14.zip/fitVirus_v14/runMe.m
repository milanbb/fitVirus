% driver
close all
coef = fitVirus03(@getDataSwitzerland);