function [country,C,date0] = getDataChina()
%GETDATA Coronavirus data
%   data from 16 Jan to 21 Jan https://i.redd.it/f4nukz4ou9d41.png
%   data from from 22 Jan 2020 to 13 Feb 2020 are from 
%   https://www.worldometers.info/coronavirus/
country = 'China';
date0=datenum('2020/01/16'); % start date
C = [
45
62
121
198
291
440
571
830
1287
1975
2744
4515
5974
7711
9690
11789
14378
17203
20438
24332
28028
31161
34546
37198
40171
42638
44438
59800
63850
66492
68500
70548
72436
74199
74576
75464
76288
76936
77150
77658
78064
78495
78824
79251
79824
80026
80151
80270
80409
80552
80651
80695
80736
80754
80778
80793
80813
80824
80844
80860
80881
80894
%<-------------- add new data here
]';
end

